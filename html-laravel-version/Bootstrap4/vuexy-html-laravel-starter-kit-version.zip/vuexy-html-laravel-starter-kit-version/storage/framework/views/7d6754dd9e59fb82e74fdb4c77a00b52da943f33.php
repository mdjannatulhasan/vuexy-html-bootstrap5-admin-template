<?php $__env->startSection('title', 'Layout collapsed menu'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="alert alert-primary" role="alert">
      <div class="alert-body">
        <strong>Info:</strong> Use this layout to set menu (navigation) default collapsed. Please check the&nbsp;<a
          class="text-primary"
          href="https://pixinvent.com/demo/vuexy-html-bootstrap-admin-template/documentation/documentation-layout-collapsed-menu.html"
          target="_blank"
          >Layout collapsed menu documentation</a
        >&nbsp; for more details.
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-starter-kit/resources/views//content/layout-collapsed-menu.blade.php ENDPATH**/ ?>